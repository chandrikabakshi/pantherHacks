package com.pantherhacks.questionprompter

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*

class MainActivity : AppCompatActivity()
{

    private lateinit var questionText: TextView
    private lateinit var answerInput: EditText
    private lateinit var submitBtn: Button

    private var questions = ArrayList<String>()
    private var currentIndex = 0
    private var score = 4

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find views
        questionText = findViewById(R.id.questionText)
        answerInput = findViewById(R.id.answerInput)
        submitBtn = findViewById(R.id.submitBtn)

        // Load questions from assets
        questions = loadQuestions()
        questions.shuffle() // randomize order

        loadNextQuestion()

        submitBtn.setOnClickListener {
            val userAnswer = answerInput.text.toString().trim()

            // Give 10 points for any answer
            if (userAnswer.isNotEmpty()) {
                score += 4
            }

            currentIndex++
            answerInput.text.clear()
            loadNextQuestion()
        }
    }

    private fun loadNextQuestion()
    {
        // ask user 5 questions daily
        if (currentIndex >= 5) {
            Toast.makeText(this, "Current stars: $score", Toast.LENGTH_LONG).show()
            questionText.text = "Answers submitted!"
            submitBtn.isEnabled = false
            answerInput.isEnabled = false
            return
        }

        // else grab next question
        questionText.text = questions[currentIndex]
    }

    private fun loadQuestions(): ArrayList<String>
    {
        val questionList = ArrayList<String>()
        try
        {
            // each line in questions.txt is its own question
            // questions source: camh.ca
            val inputStream = assets.open("questions.txt")
            val reader = BufferedReader(InputStreamReader(inputStream))
            reader.forEachLine{ line ->
                if (line.trim().isNotEmpty()) questionList.add(line.trim())
            }
            reader.close()
        } catch (e: Exception)
        {
            e.printStackTrace()
        }
        return questionList
    }
}